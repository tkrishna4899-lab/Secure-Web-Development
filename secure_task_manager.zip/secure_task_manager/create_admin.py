import sys
from app import create_app, db
from app.models import User

def create_admin():
    """Create a default admin user"""
    app = create_app()
    
    with app.app_context():
        # Check if admin already exists
        admin = User.query.filter_by(username='admin').first()
        if admin:
            print("❌ Admin user already exists!")
            return
        
        # Create admin user
        admin_user = User(
            username='admin',
            email='admin@securetaskmanager.local',
            role='admin'
        )
        admin_user.set_password('Admin@123456')  # Default password - MUST be changed on first login
        
        try:
            db.session.add(admin_user)
            db.session.commit()
            print("✅ Admin user created successfully!")
            print("\n📋 Admin Credentials:")
            print("   Username: admin")
            print("   Password: Admin@123456")
            print("\n⚠️  IMPORTANT: Change this password immediately after first login!")
            print("   Go to: http://localhost:5000/enable_2fa to set up 2FA after login")
        except Exception as e:
            db.session.rollback()
            print(f"❌ Error creating admin user: {str(e)}")
            sys.exit(1)

if __name__ == '__main__':
    create_admin()
