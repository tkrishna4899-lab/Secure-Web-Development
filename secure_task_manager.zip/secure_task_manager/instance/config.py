import os

# Replace with a strong random value in production. Do not commit.
SECRET_KEY = os.environ.get('SECRET_KEY') or 'replace_this_with_a_real_secret_key'

# SQLite DB location (instance folder keeps it out of repo)
SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///' + os.path.join(os.path.dirname(__file__), 'task_manager.db')

# Security settings recommended for production
SESSION_COOKIE_SECURE = False  # set True when using HTTPS
SESSION_COOKIE_SAMESITE = 'Lax'
REMEMBER_COOKIE_HTTPONLY = True
