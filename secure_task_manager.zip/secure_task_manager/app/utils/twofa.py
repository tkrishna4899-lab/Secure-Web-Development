import pyotp
import qrcode
import qrcode.image.svg
import io
import base64

def generate_totp_secret():
    """Return a base32 secret for TOTP."""
    return pyotp.random_base32()

def get_totp_uri(username, secret, issuer_name='SecureTaskManager'):
    """Return provisioning URI for use in authenticator apps."""
    # Account name is commonly username:email or username
    return pyotp.totp.TOTP(secret).provisioning_uri(name=username, issuer_name=issuer_name)

def verify_totp(token, secret):
    """Verify a token against the stored secret (allow small window)."""
    if not secret:
        return False
    totp = pyotp.TOTP(secret)
    # allow for larger time drift with valid_window=2 (two steps before/after)
    # This tolerates up to ±60 seconds by default (TOTP step is 30s).
    return totp.verify(token, valid_window=2)

def generate_qr_code_base64(provisioning_uri):
    """Generate a PNG QR code image as base64 data URI for embedding in <img> tags."""
    qr = qrcode.make(provisioning_uri)
    buffered = io.BytesIO()
    qr.save(buffered, format="PNG")
    img_bytes = buffered.getvalue()
    b64 = base64.b64encode(img_bytes).decode('ascii')
    return f"data:image/png;base64,{b64}"

# Optionally an SVG generator:
def generate_qr_svg_base64(provisioning_uri):
    factory = qrcode.image.svg.SvgImage
    img = qrcode.make(provisioning_uri, image_factory=factory)
    buffered = io.BytesIO()
    img.save(buffered)
    data = buffered.getvalue().decode('utf-8')
    # return raw svg string (not base64) suitable for inline embedding
    return data
