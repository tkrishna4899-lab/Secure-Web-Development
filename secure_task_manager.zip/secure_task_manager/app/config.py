import os
from datetime import timedelta

class Config:
    """Base configuration with security hardening"""
    
    # Secret key for session management - MUST be changed in production
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'change-this-secret-in-production-immediately'
    
    # Database configuration
    BASEDIR = os.path.abspath(os.path.dirname(__file__))
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(os.path.dirname(BASEDIR), 'instance', 'task_manager.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = False  # Set to True for SQL query logging in development

    # Session & Cookie Hardening
    SESSION_COOKIE_HTTPONLY = True          # Prevent JavaScript access to session cookies
    SESSION_COOKIE_SECURE = False           # Set to True in production (requires HTTPS)
    SESSION_COOKIE_SAMESITE = 'Lax'         # CSRF protection
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)  # Session expires after 7 days
    
    # Remember me cookie hardening
    REMEMBER_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SECURE = False          # Set to True in production
    REMEMBER_COOKIE_DURATION = timedelta(days=7)
    REMEMBER_COOKIE_SAMESITE = 'Lax'
    
    # CSRF Protection
    WTF_CSRF_ENABLED = True
    # Flask-WTF expects an integer (seconds) for the time limit. Use total seconds for a 6 hour window.
    WTF_CSRF_TIME_LIMIT = int(timedelta(hours=6).total_seconds())  # 6 hours in seconds
    WTF_CSRF_SSL_STRICT = False             # Set to True in production
    
    # Flask-Login Configuration
    FLASK_ENV = os.environ.get('FLASK_ENV') or 'development'
    
    # Security headers
    SESSION_COOKIE_NAME = '__Secure-SessionID' if os.environ.get('FLASK_ENV') == 'production' else 'SessionID'
    
    # Logging
    LOG_LEVEL = os.environ.get('LOG_LEVEL') or 'INFO'
    
    # Rate limiting (for future implementation)
    RATELIMIT_ENABLED = True
    RATELIMIT_STORAGE_URL = 'memory://'
    
    # Password requirements
    MIN_PASSWORD_LENGTH = 8
    REQUIRE_UPPERCASE = True
    REQUIRE_NUMBERS = False
    REQUIRE_SPECIAL_CHARS = False
