/* ============================================
   Secure Task Manager - JavaScript
   ============================================ */

// Document ready
document.addEventListener('DOMContentLoaded', function () {
  initializeFeatures();
});

// Initialize all features
function initializeFeatures() {
  setupFormValidation();
  setupSmoothScroll();
  setupDynamicAlerts();
  setupTaskCardAnimations();
  setupPasswordStrengthMeter();
  setupTooltips();
  setupConfirmDialogs();
}

/* ============================================
   FORM VALIDATION
   ============================================ */

function setupFormValidation() {
  const forms = document.querySelectorAll('form[novalidate]');
  forms.forEach((form) => {
    form.addEventListener('submit', function (e) {
      const inputs = form.querySelectorAll('input, textarea, select');
      let isValid = true;

      inputs.forEach((input) => {
        if (!input.value.trim() && input.hasAttribute('required')) {
          markInvalid(input, 'This field is required');
          isValid = false;
        } else if (input.type === 'email' && input.value.trim()) {
          if (!isValidEmail(input.value)) {
            markInvalid(input, 'Please enter a valid email');
            isValid = false;
          } else {
            markValid(input);
          }
        } else if (input.type === 'password' && input.value.trim()) {
          const minLength = input.getAttribute('data-min-length') || 8;
          if (input.value.length < minLength) {
            markInvalid(
              input,
              `Password must be at least ${minLength} characters`
            );
            isValid = false;
          } else {
            markValid(input);
          }
        } else if (input.classList.contains('validate-match')) {
          const matchTarget = document.querySelector(
            input.getAttribute('data-match')
          );
          if (matchTarget && input.value !== matchTarget.value) {
            markInvalid(input, 'Passwords do not match');
            isValid = false;
          } else {
            markValid(input);
          }
        } else if (input.value.trim()) {
          markValid(input);
        }
      });

      if (!isValid) {
        e.preventDefault();
      }
    });

    // Real-time validation
    const inputs = form.querySelectorAll('input, textarea, select');
    inputs.forEach((input) => {
      input.addEventListener('blur', function () {
        validateInput(this);
      });

      input.addEventListener('input', function () {
        if (this.classList.contains('is-invalid')) {
          validateInput(this);
        }
      });
    });
  });
}

function validateInput(input) {
  if (!input.value.trim() && input.hasAttribute('required')) {
    markInvalid(input, 'This field is required');
  } else if (input.type === 'email' && input.value.trim()) {
    if (!isValidEmail(input.value)) {
      markInvalid(input, 'Please enter a valid email');
    } else {
      markValid(input);
    }
  } else if (input.value.trim()) {
    markValid(input);
  }
}

function markInvalid(input, message) {
  input.classList.add('is-invalid');
  input.classList.remove('is-valid');
  const errorDiv = input.nextElementSibling;
  if (errorDiv && errorDiv.classList.contains('text-danger')) {
    errorDiv.textContent = message;
  }
}

function markValid(input) {
  input.classList.remove('is-invalid');
  input.classList.add('is-valid');
}

function isValidEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

/* ============================================
   PASSWORD STRENGTH METER
   ============================================ */

function setupPasswordStrengthMeter() {
  const passwordInputs = document.querySelectorAll('input[type="password"]');
  passwordInputs.forEach((input) => {
    // Skip 2FA token inputs
    if (input.classList.contains('totp-input')) {
      return;
    }

    input.addEventListener('input', function () {
      const strength = calculatePasswordStrength(this.value);
      showPasswordStrengthFeedback(this, strength);
    });
  });
}

function calculatePasswordStrength(password) {
  let strength = 0;

  if (password.length >= 8) strength++;
  if (password.length >= 12) strength++;
  if (/[a-z]/.test(password)) strength++;
  if (/[A-Z]/.test(password)) strength++;
  if (/[0-9]/.test(password)) strength++;
  if (/[^a-zA-Z0-9]/.test(password)) strength++;

  return strength;
}

function showPasswordStrengthFeedback(input, strength) {
  let feedback = input.nextElementSibling;

  if (!feedback || !feedback.classList.contains('password-strength')) {
    feedback = document.createElement('div');
    feedback.className = 'password-strength';
    input.parentNode.insertBefore(feedback, input.nextSibling);
  }

  let strengthText = '';
  let strengthColor = '';

  if (strength <= 2) {
    strengthText = '❌ Weak';
    strengthColor = 'danger';
  } else if (strength <= 4) {
    strengthText = '⚠️ Fair';
    strengthColor = 'warning';
  } else if (strength <= 5) {
    strengthText = '✓ Good';
    strengthColor = 'info';
  } else {
    strengthText = '✓✓ Strong';
    strengthColor = 'success';
  }

  feedback.innerHTML = `<small class="text-${strengthColor}">${strengthText}</small>`;
}

/* ============================================
   SMOOTH SCROLL
   ============================================ */

function setupSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
      const href = this.getAttribute('href');
      if (href !== '#') {
        e.preventDefault();
        const target = document.querySelector(href);
        if (target) {
          target.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
          });
        }
      }
    });
  });
}

/* ============================================
   DYNAMIC ALERTS
   ============================================ */

function setupDynamicAlerts() {
  const alerts = document.querySelectorAll('.alert');
  alerts.forEach((alert) => {
    const closeBtn = alert.querySelector('.btn-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', function () {
        alert.style.animation = 'slideInDown 0.3s ease reverse';
        setTimeout(() => alert.remove(), 300);
      });
    }

    // Auto-close success and info alerts after 5 seconds
    if (alert.classList.contains('alert-success') || alert.classList.contains('alert-info')) {
      setTimeout(() => {
        if (alert.parentNode) {
          alert.style.animation = 'slideInDown 0.3s ease reverse';
          setTimeout(() => alert.remove(), 300);
        }
      }, 5000);
    }
  });
}

/* ============================================
   TASK CARD ANIMATIONS
   ============================================ */

function setupTaskCardAnimations() {
  const taskCards = document.querySelectorAll('.task-card, .list-group-item');
  taskCards.forEach((card, index) => {
    card.style.animation = `slideInUp 0.3s ease ${index * 0.1}s both`;
  });
}

/* ============================================
   TOOLTIPS
   ============================================ */

function setupTooltips() {
  const tooltips = document.querySelectorAll('[data-tooltip]');
  tooltips.forEach((element) => {
    element.addEventListener('mouseenter', function () {
      const tooltip = createTooltip(this.getAttribute('data-tooltip'));
      document.body.appendChild(tooltip);
      positionTooltip(tooltip, this);
    });

    element.addEventListener('mouseleave', function () {
      const tooltips = document.querySelectorAll('.tooltip-popup');
      tooltips.forEach((t) => t.remove());
    });
  });
}

function createTooltip(text) {
  const tooltip = document.createElement('div');
  tooltip.className = 'tooltip-popup';
  tooltip.textContent = text;
  tooltip.style.cssText = `
    position: fixed;
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 0.5rem 0.75rem;
    border-radius: 6px;
    font-size: 0.875rem;
    white-space: nowrap;
    z-index: 1000;
    pointer-events: none;
  `;
  return tooltip;
}

function positionTooltip(tooltip, element) {
  const rect = element.getBoundingClientRect();
  tooltip.style.left = rect.left + rect.width / 2 - tooltip.offsetWidth / 2 + 'px';
  tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
}

/* ============================================
   CONFIRM DIALOGS
   ============================================ */

function setupConfirmDialogs() {
  const forms = document.querySelectorAll('form[method="post"]');
  forms.forEach((form) => {
    const deleteButtons = form.querySelectorAll('[type="submit"][class*="danger"]');
    deleteButtons.forEach((button) => {
      if (!button.hasAttribute('data-confirm-setup')) {
        button.addEventListener('click', function (e) {
          if (!confirm(this.getAttribute('data-confirm') || 'Are you sure?')) {
            e.preventDefault();
            return false;
          }
        });
        button.setAttribute('data-confirm-setup', 'true');
      }
    });
  });
}

/* ============================================
   UTILITY FUNCTIONS
   ============================================ */

// Show notification
function showNotification(message, type = 'info', duration = 3000) {
  const alertDiv = document.createElement('div');
  alertDiv.className = `alert alert-${type} alert-dismissible fade show slide-in-up`;
  alertDiv.innerHTML = `
    ${message}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  `;

  const container =
    document.querySelector('.container') || document.body;
  container.insertBefore(alertDiv, container.firstChild);

  setTimeout(() => {
    if (alertDiv.parentNode) {
      alertDiv.remove();
    }
  }, duration);
}

// Format date
function formatDate(date) {
  const options = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  };
  return new Date(date).toLocaleDateString(undefined, options);
}

// Copy to clipboard
function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    showNotification('✓ Copied to clipboard!', 'success');
  });
}

// Toggle between list and grid view (for future use)
function toggleViewMode(mode) {
  const taskContainer = document.querySelector('.task-container');
  if (taskContainer) {
    taskContainer.classList.toggle('list-view', mode === 'list');
    taskContainer.classList.toggle('grid-view', mode === 'grid');
    localStorage.setItem('viewMode', mode);
  }
}

// Remember user preferences
function saveUserPreference(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function getUserPreference(key, defaultValue = null) {
  const stored = localStorage.getItem(key);
  return stored ? JSON.parse(stored) : defaultValue;
}

// Lazy load images
function setupLazyLoading() {
  const images = document.querySelectorAll('img[data-src]');
  if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.getAttribute('data-src');
          img.removeAttribute('data-src');
          observer.unobserve(img);
        }
      });
    });

    images.forEach((img) => imageObserver.observe(img));
  } else {
    images.forEach((img) => {
      img.src = img.getAttribute('data-src');
    });
  }
}

// Initialize lazy loading when page loads
window.addEventListener('load', setupLazyLoading);

/* ============================================
   KEYBOARD SHORTCUTS
   ============================================ */

document.addEventListener('keydown', function (e) {
  // Focus search (Cmd/Ctrl + K)
  if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
    e.preventDefault();
    const searchInput = document.querySelector('[data-search]');
    if (searchInput) {
      searchInput.focus();
    }
  }

  // Submit form (Cmd/Ctrl + Enter)
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    const form = document.querySelector('form:focus-within');
    if (form) {
      form.submit();
    }
  }
});

/* ============================================
   DARK MODE TOGGLE (Optional)
   ============================================ */

function toggleDarkMode() {
  document.documentElement.classList.toggle('dark-mode');
  const isDark = document.documentElement.classList.contains('dark-mode');
  localStorage.setItem('darkMode', isDark);
}

// Initialize dark mode if previously enabled
function initializeDarkMode() {
  if (localStorage.getItem('darkMode') === 'true') {
    document.documentElement.classList.add('dark-mode');
  }
}

// Detect system preference
function respendToSystemPreference() {
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
  prefersDark.addListener((e) => {
    if (e.matches && !localStorage.getItem('darkMode')) {
      document.documentElement.classList.add('dark-mode');
    } else {
      document.documentElement.classList.remove('dark-mode');
    }
  });
}

// Export for use in other scripts
window.Utils = {
  showNotification,
  formatDate,
  copyToClipboard,
  toggleViewMode,
  saveUserPreference,
  getUserPreference,
  toggleDarkMode,
};
