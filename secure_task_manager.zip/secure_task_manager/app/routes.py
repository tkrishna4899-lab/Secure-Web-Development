from flask import Blueprint, render_template, flash, redirect, url_for, request, session, current_app, abort
from . import db, login_manager
from .models import User, Task, LoginAttempt
from .forms import RegistrationForm, LoginForm, TwoFactorForm, TaskForm, EmptyForm
from .utils.twofa import generate_totp_secret, get_totp_uri, verify_totp, generate_qr_code_base64
from .utils.security import role_required
from flask_login import login_user, logout_user, current_user, login_required
from urllib.parse import urlparse
from flask_wtf.csrf import generate_csrf
import logging

bp = Blueprint('auth', __name__)
logger = logging.getLogger(__name__)

@bp.route('/')
def index():
    """Home page"""
    return render_template('index.html')

@bp.route('/register', methods=['GET', 'POST'])
def register():
    """User registration"""
    if current_user.is_authenticated:
        return redirect(url_for('auth.dashboard'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        try:
            user = User(username=form.username.data.strip(),
                        email=form.email.data.strip(),
                        role='user')
            user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()
            logger.info(f'New user registered: {user.username}')
            flash('Registration successful. Please log in.', 'success')
            return redirect(url_for('auth.login'))
        except Exception as e:
            db.session.rollback()
            logger.error(f'Registration error: {str(e)}')
            flash('An error occurred during registration. Please try again.', 'danger')
    
    return render_template('register.html', form=form)

@bp.route('/login', methods=['GET', 'POST'])
def login():
    """User login with optional 2FA"""
    if current_user.is_authenticated:
        return redirect(url_for('auth.dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data.strip()).first()
        ip = request.remote_addr
        
        try:
            attempt = LoginAttempt(
                username=form.username.data.strip(),
                ip_address=ip,
                user_id=user.id if user else None
            )
            
            if user and user.check_password(form.password.data):
                attempt.success = True
                db.session.add(attempt)
                db.session.commit()
                user.update_last_login()
                
                logger.info(f'Successful login: {user.username} from {ip}')
                
                # If user has 2FA enabled: store pre-2fa and redirect to verify
                if user.is_2fa_enabled and user.totp_secret:
                    session['pre_2fa_userid'] = user.id
                    session['remember_me'] = form.remember.data
                    flash('Password correct. Please enter your 2FA code.', 'info')
                    return redirect(url_for('auth.verify_2fa'))
                
                # otherwise full login
                login_user(user, remember=form.remember.data)
                next_page = request.args.get('next')
                if not next_page or urlparse(next_page).netloc != '':
                    next_page = url_for('auth.dashboard')
                
                flash(f'Welcome back, {user.username}!', 'success')
                return redirect(next_page)
            else:
                attempt.success = False
                db.session.add(attempt)
                db.session.commit()
                
                if user:
                    logger.warning(f'Failed login attempt: {user.username} from {ip}')
                else:
                    logger.warning(f'Failed login attempt: unknown user from {ip}')
                
                flash('Invalid username or password', 'danger')
        except Exception as e:
            db.session.rollback()
            logger.error(f'Login error: {str(e)}')
            flash('An error occurred during login. Please try again.', 'danger')
    
    return render_template('login.html', form=form)

@bp.route('/verify-2fa', methods=['GET', 'POST'])
def verify_2fa():
    """Verify TOTP 2FA code during login"""
    if current_user.is_authenticated:
        return redirect(url_for('auth.dashboard'))
    
    user_id = session.get('pre_2fa_userid')
    if not user_id:
        flash('No 2FA authentication pending. Please log in.', 'warning')
        return redirect(url_for('auth.login'))
    
    user = User.query.get(user_id)
    if not user:
        session.clear()
        flash('User not found. Please log in again.', 'danger')
        return redirect(url_for('auth.login'))

    form = TwoFactorForm()
    if form.validate_on_submit():
        token = form.token.data.strip()
        
        try:
            if verify_totp(token, user.totp_secret):
                # success: log in the user
                remember = session.pop('remember_me', False)
                session.pop('pre_2fa_userid', None)
                
                login_user(user, remember=remember)
                user.update_last_login()
                
                logger.info(f'Successful 2FA login: {user.username}')
                flash('2FA verified successfully. Welcome!', 'success')
                return redirect(url_for('auth.dashboard'))
            else:
                logger.warning(f'Failed 2FA attempt: {user.username}')
                flash('Invalid authentication code. Please try again.', 'danger')
        except Exception as e:
            logger.error(f'2FA verification error: {str(e)}')
            flash('An error occurred during verification. Please try again.', 'danger')
    
    return render_template('verify_2fa.html', form=form)

@bp.route('/enable-2fa', methods=['GET', 'POST'])
@login_required
def enable_2fa():
    """Enable TOTP 2FA for user"""
    if current_user.is_2fa_enabled and current_user.totp_secret:
        flash('2FA is already enabled on your account.', 'info')
        return redirect(url_for('auth.dashboard'))

    # If user already has secret stored but not enabled, reuse it. Else generate.
    if not current_user.totp_secret:
        secret = generate_totp_secret()
        current_user.totp_secret = secret
        db.session.commit()
    else:
        secret = current_user.totp_secret

    provisioning_uri = get_totp_uri(current_user.username, secret)
    qr_data_uri = generate_qr_code_base64(provisioning_uri)

    form = TwoFactorForm()
    if form.validate_on_submit():
        token = form.token.data.strip()
        
        try:
            if verify_totp(token, secret):
                current_user.is_2fa_enabled = True
                db.session.commit()
                logger.info(f'2FA enabled for user: {current_user.username}')
                flash('2FA enabled successfully! Your account is now more secure.', 'success')
                return redirect(url_for('auth.dashboard'))
            else:
                logger.warning(f'Invalid 2FA setup token for: {current_user.username}')
                flash('Invalid token. Please try again.', 'danger')
        except Exception as e:
            db.session.rollback()
            logger.error(f'2FA setup error for {current_user.username}: {str(e)}')
            flash('An error occurred. Please try again.', 'danger')

    # Ensure a CSRF token is present in the session before rendering the form
    try:
        generate_csrf()
    except Exception:
        # If token generation fails, continue to render the page; the form will display errors on submit
        logger.debug('Could not generate CSRF token before rendering enable_2fa page')

    return render_template('enable_2fa.html', qr_data_uri=qr_data_uri, provisioning_uri=provisioning_uri, secret=secret, form=form)

@bp.route('/disable-2fa', methods=['POST'])
@login_required
def disable_2fa():
    """Disable TOTP 2FA for user"""
    form = EmptyForm()
    if form.validate_on_submit():
        try:
            current_user.is_2fa_enabled = False
            current_user.totp_secret = None
            db.session.commit()
            logger.info(f'2FA disabled for user: {current_user.username}')
            flash('2FA has been disabled for your account.', 'info')
        except Exception as e:
            db.session.rollback()
            logger.error(f'2FA disable error for {current_user.username}: {str(e)}')
            flash('An error occurred. Please try again.', 'danger')
    
    return redirect(url_for('auth.dashboard'))

@bp.route('/logout')
@login_required
def logout():
    """User logout"""
    username = current_user.username
    logout_user()
    logger.info(f'User logged out: {username}')
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('auth.index'))

@bp.route('/dashboard')
@login_required
def dashboard():
    """User dashboard"""
    try:
        # show user's tasks (admin sees all tasks)
        if current_user.role == 'admin':
            tasks = Task.query.order_by(Task.created_at.desc()).all()
        else:
            tasks = current_user.tasks.order_by(Task.created_at.desc()).all()
        
        return render_template('dashboard.html', tasks=tasks)
    except Exception as e:
        logger.error(f'Dashboard error for {current_user.username}: {str(e)}')
        flash('An error occurred loading your dashboard.', 'danger')
        return redirect(url_for('auth.index'))

# TASK CRUD
@bp.route('/tasks')
@login_required
def list_tasks():
    """List all tasks (user sees only own, admin sees all)"""
    try:
        if current_user.role == 'admin':
            tasks = Task.query.order_by(Task.created_at.desc()).all()
        else:
            tasks = current_user.tasks.order_by(Task.created_at.desc()).all()
        
        return render_template('tasks/list_tasks.html', tasks=tasks)
    except Exception as e:
        logger.error(f'Task list error for {current_user.username}: {str(e)}')
        flash('An error occurred loading tasks.', 'danger')
        return redirect(url_for('auth.dashboard'))

@bp.route('/tasks/add', methods=['GET', 'POST'])
@login_required
def add_task():
    """Create a new task"""
    form = TaskForm()
    if form.validate_on_submit():
        try:
            task = Task(
                title=form.title.data.strip(),
                description=form.description.data.strip(),
                owner=current_user
            )
            db.session.add(task)
            db.session.commit()
            logger.info(f'New task created by {current_user.username}: {task.title}')
            flash('Task created successfully.', 'success')
            return redirect(url_for('auth.list_tasks'))
        except Exception as e:
            db.session.rollback()
            logger.error(f'Task creation error for {current_user.username}: {str(e)}')
            flash('An error occurred creating the task.', 'danger')
    
    return render_template('tasks/add_task.html', form=form)

@bp.route('/tasks/<int:task_id>')
@login_required
def view_task(task_id):
    """View a specific task"""
    task = Task.query.get_or_404(task_id)
    
    # access control: users can only view own tasks unless admin
    if task.user_id != current_user.id and current_user.role != 'admin':
        logger.warning(f'Unauthorized task view attempt by {current_user.username} for task {task_id}')
        abort(403)
    
    return render_template('tasks/view_task.html', task=task)

@bp.route('/tasks/<int:task_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_task(task_id):
    """Edit a task"""
    task = Task.query.get_or_404(task_id)
    
    # access control: users can only edit own tasks unless admin
    if task.user_id != current_user.id and current_user.role != 'admin':
        logger.warning(f'Unauthorized task edit attempt by {current_user.username} for task {task_id}')
        abort(403)
    
    form = TaskForm(obj=task)
    if form.validate_on_submit():
        try:
            task.title = form.title.data.strip()
            task.description = form.description.data.strip()
            db.session.commit()
            logger.info(f'Task updated by {current_user.username}: {task.title}')
            flash('Task updated successfully.', 'success')
            return redirect(url_for('auth.view_task', task_id=task.id))
        except Exception as e:
            db.session.rollback()
            logger.error(f'Task update error for {current_user.username}: {str(e)}')
            flash('An error occurred updating the task.', 'danger')
    
    return render_template('tasks/edit_task.html', form=form, task=task)

@bp.route('/tasks/<int:task_id>/delete', methods=['POST'])
@login_required
def delete_task(task_id):
    """Delete a task"""
    task = Task.query.get_or_404(task_id)
    
    # access control: users can only delete own tasks unless admin
    if task.user_id != current_user.id and current_user.role != 'admin':
        logger.warning(f'Unauthorized task delete attempt by {current_user.username} for task {task_id}')
        abort(403)
    
    form = EmptyForm()
    if form.validate_on_submit():
        try:
            task_title = task.title
            db.session.delete(task)
            db.session.commit()
            logger.info(f'Task deleted by {current_user.username}: {task_title}')
            flash('Task deleted successfully.', 'info')
        except Exception as e:
            db.session.rollback()
            logger.error(f'Task delete error for {current_user.username}: {str(e)}')
            flash('An error occurred deleting the task.', 'danger')
    
    return redirect(url_for('auth.list_tasks'))

# ADMIN: manage users
@bp.route('/admin/users')
@login_required
@role_required('admin')
def manage_users():
    """Admin: manage all users"""
    try:
        users = User.query.order_by(User.created_at.desc()).all()
        logger.info(f'Admin user management accessed by {current_user.username}')
        return render_template('admin/manage_users.html', users=users)
    except Exception as e:
        logger.error(f'User management error for {current_user.username}: {str(e)}')
        flash('An error occurred loading the user list.', 'danger')
        return redirect(url_for('auth.dashboard'))

@bp.route('/admin/user/<int:user_id>')
@login_required
@role_required('admin')
def user_detail(user_id):
    """Admin: view user details"""
    user = User.query.get_or_404(user_id)
    logger.info(f'Admin viewed user details for {user.username} by {current_user.username}')
    return render_template('admin/user_detail.html', user=user)
