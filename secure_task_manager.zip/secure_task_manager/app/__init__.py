import os
import logging
from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from flask_migrate import Migrate

db = SQLAlchemy()
login_manager = LoginManager()
csrf = CSRFProtect()
migrate = Migrate()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    
    # Default config
    app.config.from_object('app.config.Config')

    # Override from instance config if exists
    instance_cfg = os.path.join(app.instance_path, 'config.py')
    if os.path.exists(instance_cfg):
        app.config.from_pyfile('config.py')

    if test_config:
        app.config.update(test_config)

    # ensure instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    # init extensions
    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    migrate.init_app(app, db)

    login_manager.login_view = 'auth.login'
    login_manager.login_message_category = "info"
    login_manager.login_message = "Please log in to access this page."

    # User loader for Flask-Login
    @login_manager.user_loader
    def load_user(user_id):
        from .models import User
        return User.query.get(int(user_id))

    # Error handlers
    @app.errorhandler(404)
    def page_not_found(error):
        return render_template('errors/404.html'), 404

    @app.errorhandler(403)
    def forbidden(error):
        return render_template('errors/403.html'), 403

    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        logger.error(f'Server Error: {error}')
        return render_template('errors/500.html'), 500

    # blueprints (simple single-file structure here)
    from . import routes
    app.register_blueprint(routes.bp)

    # Create tables if they don't exist
    with app.app_context():
        db.create_all()

    logger.info('Application initialized successfully')
    return app
